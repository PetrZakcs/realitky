import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ExternalLink, ArrowLeft } from "lucide-react";

interface PropertyResult {
  title: string;
  price: string;
  locality: string;
  image: string;
  url: string;
  source: string;
}

const Results = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get("q");
  const [results, setResults] = useState<PropertyResult[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (!query) {
      navigate("/");
      return;
    }

    const fetchResults = async () => {
      setIsLoading(true);
      
      try {
        const response = await fetch("/api/search", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ query }),
        });

        if (!response.ok) {
          throw new Error("Chyba při vyhledávání");
        }

        const data = await response.json();
        setResults(data);
        
        if (data.length === 0) {
          toast({
            title: "Žádné výsledky",
            description: "Zkuste upravit vyhledávací dotaz",
          });
        }
      } catch (error) {
        toast({
          title: "Chyba",
          description: "Nepodařilo se vyhledat nemovitosti. Zkuste to prosím znovu.",
          variant: "destructive",
        });
        console.error("Search error:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchResults();
  }, [query, navigate, toast]);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="w-full max-w-5xl mx-auto space-y-6">
        {/* Header with back button */}
        <div className="flex items-center gap-4 animate-fade-in">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/")}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Zpět
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Výsledky vyhledávání</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Dotaz: <span className="font-medium text-foreground">{query}</span>
            </p>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <Card className="p-12 shadow-lg border-0 animate-fade-in">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="loading-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
              <p className="text-muted-foreground">Vyhledávám nemovitosti...</p>
            </div>
          </Card>
        )}

        {/* Results Table */}
        {!isLoading && results.length > 0 && (
          <Card className="overflow-hidden shadow-lg border-0 animate-fade-in">
            <div className="p-4 bg-muted/50 border-b">
              <p className="text-sm font-medium">
                Nalezeno <span className="text-primary">{results.length}</span> nemovitostí
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left p-4 font-semibold text-sm">Název</th>
                    <th className="text-left p-4 font-semibold text-sm">Lokalita</th>
                    <th className="text-left p-4 font-semibold text-sm">Cena</th>
                    <th className="text-left p-4 font-semibold text-sm">Zdroj</th>
                    <th className="text-left p-4 font-semibold text-sm">Odkaz</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((result, index) => (
                    <tr
                      key={index}
                      className="border-b last:border-b-0 hover:bg-muted/30 transition-colors"
                    >
                      <td className="p-4">
                        <div className="font-medium">{result.title}</div>
                      </td>
                      <td className="p-4 text-muted-foreground">{result.locality}</td>
                      <td className="p-4 font-semibold">{result.price}</td>
                      <td className="p-4 text-muted-foreground text-sm">{result.source}</td>
                      <td className="p-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(result.url, "_blank")}
                          className="gap-2"
                        >
                          Otevřít
                          <ExternalLink className="h-3 w-3" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* No Results */}
        {!isLoading && results.length === 0 && (
          <Card className="p-12 shadow-lg border-0 animate-fade-in text-center">
            <p className="text-lg text-muted-foreground mb-4">
              Nenašli jsme žádné nemovitosti odpovídající vašemu dotazu.
            </p>
            <Button onClick={() => navigate("/")}>
              Zkusit nové vyhledávání
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Results;
