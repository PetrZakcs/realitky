import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Search } from "lucide-react";

const Index = () => {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSearch = () => {
    if (!query.trim()) {
      toast({
        title: "Chyba",
        description: "Prosím zadejte vyhledávací dotaz",
        variant: "destructive",
      });
      return;
    }

    navigate(`/results?q=${encodeURIComponent(query)}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSearch();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-5xl space-y-8">
        {/* Header */}
        <div className="text-center space-y-3 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Inteligentní vyhledávač nemovitostí
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Zadejte, co hledáte, a já vyhledám nejvhodnější nabídky.
          </p>
        </div>

        {/* Search Card */}
        <Card className="p-6 md:p-8 shadow-lg border-0 animate-scale-in">
          <div className="space-y-4">
            <Textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Např. Byt 2+1 v Praze do 6 milionů, nejlépe Žižkov / Vinohrady."
              className="min-h-[120px] text-base resize-none focus-visible:ring-primary"
            />
            <Button
              onClick={handleSearch}
              size="lg"
              className="w-full md:w-auto font-medium gap-2"
            >
              <Search className="h-4 w-4" />
              Vyhledat
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Index;
